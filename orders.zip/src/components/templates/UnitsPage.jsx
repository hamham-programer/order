import React, { useEffect, useState } from 'react';
import { createUnit, getUnits, deleteUnit } from '../../services/admin'; 
import styles from './UnitsPage.module.css'; 

function UnitsPage() {
  const [units, setUnits] = useState([]);
  const [workLocation, setWorkLocation] = useState('نازگل');
  const [organizationName, setOrganizationName] = useState(''); // نام واحد
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUnits = async () => {
      try {
        const response = await getUnits();
        if (Array.isArray(response.data)) {
          setUnits(response.data);
        } else {
          setError('داده‌ها به درستی دریافت نشدند.');
        }
      } catch (error) {
        setError('خطا در دریافت واحدها');
      }
    };
  
    fetchUnits();
  }, []);

  const handleAddUnit = async (e) => {
    e.preventDefault();
    if (!workLocation || !organizationName) {
      setError('لطفاً تمام فیلدها را پر کنید.');
      return;
    }

    try {
      const newUnit = { 
        workLocation, 
        organization: { name: organizationName } // ارسال فقط نام واحد
      };

      const createdUnit = await createUnit(newUnit);

      if (createdUnit && createdUnit.data) {
        setUnits(prevUnits => [...prevUnits, { ...newUnit, _id: createdUnit.data._id }]);
      } else {
        setError('خطا در دریافت اطلاعات واحد جدید.');
      }

      setWorkLocation('');
      setOrganizationName('');
      setError('');
    } catch (error) {
      console.error("خطا در ایجاد واحد:", error);
      setError('خطا در ایجاد واحد');
    }
  };

  const handleDeleteUnit = async (id) => {
    try {
      await deleteUnit(id);
      setUnits(units.filter(unit => unit._id !== id));
    } catch (error) {
      setError('خطا در حذف واحد');
    }
  };

  return (
    <div className={styles.container}>
      <h1 className={styles.title}>مدیریت واحدها</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}

      <form onSubmit={handleAddUnit} className={styles.form}>
        <div className={styles.inputGroup}>
          <input
            type="text"
            placeholder="محل کار"
            value={workLocation}
            onChange={(e) => setWorkLocation(e.target.value)}
            className={styles.input}
            required
          />
          <input
            type="text"
            placeholder="نام واحد"
            value={organizationName}
            onChange={(e) => setOrganizationName(e.target.value)}
            className={styles.input}
            required
          />
          <button type="submit" className={styles.button}>ایجاد</button>
        </div>
      </form>

      <ul className={styles.unitList}>
        {Array.isArray(units) && units.length > 0 ? (
          units.map((unit) => (
            <li key={unit._id} className={styles.unitItem}>
              <span className={styles.unitTitle}>
                {unit.workLocation ? unit.workLocation : 'محل کار نامشخص'} - 
                {unit.organization.name ? unit.organization.name : 'سازمان نامشخص'}
              </span>
              <div className={styles.deleteButtonContainer}>
                <button onClick={() => handleDeleteUnit(unit._id)} className={styles.unitDeleteButton}>
                  حذف
                </button>
              </div>
            </li>
          ))
        ) : (
          <p>هیچ واحدی وجود ندارد.</p>
        )}
      </ul>
    </div>
  );
}

export default UnitsPage;
