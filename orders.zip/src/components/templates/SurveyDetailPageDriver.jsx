import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getSurveyById, submitResponse, getDrivers } from '../../services/admin';
import { useUser } from '../../router/UserContext';
import styles from './SurveyDetailPage.module.css';

const SurveyDetailPageDriver = () => {
  const { surveyId } = useParams();
  const navigate = useNavigate();
  const { userId, userUnit } = useUser();

  const [survey, setSurvey] = useState(null);
  const [responses, setResponses] = useState({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [drivers, setDrivers] = useState([]);
  const [selectedOutgoingDriver, setSelectedOutgoingDriver] = useState(null);
  const [selectedReturnDriver, setSelectedReturnDriver] = useState(null);
  const [filteredQuestions, setFilteredQuestions] = useState([]);

  useEffect(() => {
    const fetchSurvey = async () => {
      try {
        const response = await getSurveyById(surveyId);
     /*    console.log("Fetched Survey:", response.data.survey); */
        setSurvey(response.data.survey);
      } catch (error) {
        console.error("Error fetching survey:", error);
        setError('مشکل در دریافت نظرسنجی');
      } finally {
        setLoading(false);
      }
    };

    const fetchDrivers = async () => {
      try {
        const driversResponse = await getDrivers();
       /*  console.log("Fetched Drivers:", driversResponse.data); */
        setDrivers(driversResponse.data);
      } catch (error) {
        console.error("Error fetching drivers:", error);
        setError('مشکل در دریافت اطلاعات راننده‌ها');
      }
    };

    fetchSurvey();
    fetchDrivers();
  }, [surveyId]);

  useEffect(() => {
    if (survey && (selectedOutgoingDriver || selectedReturnDriver)) {
      let questions = [];
  
      if (selectedOutgoingDriver && selectedReturnDriver && selectedOutgoingDriver === selectedReturnDriver) {
        // نمایش سوالات فقط برای راننده‌ای که هم مسیر رفت و هم برگشت است
        questions = survey.questions.filter(question =>
          question.driverId?.toString() === selectedOutgoingDriver?.toString()
        );
      } else {
        // نمایش سوالات بر اساس راننده‌های مسیر رفت و برگشت
        questions = survey.questions.filter(question => {
          const isOutgoingMatch = selectedOutgoingDriver && question.driverId?.toString() === selectedOutgoingDriver?.toString();
          const isReturnMatch = selectedReturnDriver && question.driverId?.toString() === selectedReturnDriver?.toString();
  
          return isOutgoingMatch || isReturnMatch;
        });
      }
  
      console.log("Filtered Questions:", questions);
      setFilteredQuestions(questions);
      setCurrentQuestionIndex(0); // بازنشانی به سوال اول پس از فیلتر
    }
  }, [survey, selectedOutgoingDriver, selectedReturnDriver]);
  
  const handleSubmitResponses = async () => {
    if (!userUnit) {
      setError('واحد کاربر مشخص نشده است.');
      return;
    }

    const allQuestionsAnswered = filteredQuestions.every(question => responses[question._id] !== undefined);
    console.log("All questions answered:", allQuestionsAnswered);

    if (!allQuestionsAnswered) {
      alert('لطفاً به تمام سوالات پاسخ دهید.');
      return;
    }

    const formattedAnswers = filteredQuestions.map(question => ({
      questionId: question._id,
      answer: responses[question._id] || '',
      answerType: question.type,
      driverId:question.driverId
    }));
    const driverInfo = {
      outgoingDriver: selectedOutgoingDriver,
      returnDriver: selectedReturnDriver,
    };

    try {
      console.log("Submitting responses:", { surveyId, user: userId, unit: userUnit, answers: formattedAnswers, driverInfo });
      await submitResponse({ surveyId, user: userId, unit: userUnit, answers: formattedAnswers, driverInfo });
      setSuccess(true);
      setError(null);
      navigate('/');
    } catch (error) {
      console.error("Error submitting responses:", error);
      setError('پاسخ ها ثبت نشدند');
      setSuccess(false);
    }
  };

  const handleDriverChange = (type, value) => {
    console.log("Driver change:", type, value);
    if (type === 'outgoing') setSelectedOutgoingDriver(value);
    if (type === 'return') setSelectedReturnDriver(value);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div className={styles.error}>{error}</div>;

  const currentQuestion = filteredQuestions[currentQuestionIndex];

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>{survey?.title}</h2>
      {success && <div className={styles.success}>پاسخ ها با موفقیت ثبت شدند!</div>}

      <div className={styles.driverSelection}>
        <label>راننده رفت:</label>
        <select onChange={(e) => handleDriverChange('outgoing', e.target.value)} value={selectedOutgoingDriver || ''}>
          <option value="">انتخاب راننده رفت</option>
          {drivers.map(driver => (
            <option key={driver.id} value={driver._id}>{driver.name}</option>
          ))}
        </select>
        <label>راننده برگشت:</label>
        <select onChange={(e) => handleDriverChange('return', e.target.value)} value={selectedReturnDriver || ''}>
          <option value="">انتخاب راننده برگشت</option>
          {drivers.map(driver => (
            <option key={driver.id} value={driver._id}>{driver.name}</option>
          ))}
        </select>
      </div>

      {currentQuestion && (
        <div className={styles.questionContainer}>
          <p className={styles.questionText}>{currentQuestion.text}</p>
          {currentQuestion.type === 'text' && (
            <input
              type="text"
              value={responses[currentQuestion._id] || ''}
              onChange={(e) => setResponses(prev => ({ ...prev, [currentQuestion._id]: e.target.value }))} />
          )}
          {currentQuestion.type === 'multiple-choice' && (
            <div>
              {currentQuestion.options.map((option, index) => (
                <label key={index}>
                  <input
                    type="radio"
                    name={currentQuestion._id}
                    value={option}
                    checked={responses[currentQuestion._id] === option}
                    onChange={() => setResponses(prev => ({ ...prev, [currentQuestion._id]: option }))}
                  />
                  {option}
                </label>
              ))}
            </div>
          )}
        </div>
      )}


      <div className={styles.buttons}>
        {currentQuestionIndex > 0 && (
          <button onClick={() => setCurrentQuestionIndex(currentQuestionIndex - 1)} className={styles.button}>سوال قبلی</button>
        )}
        {currentQuestionIndex < filteredQuestions.length - 1 ? (
          <button onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)} className={styles.button}>سوال بعدی</button>
        ) : (
          <button onClick={handleSubmitResponses} className={`${styles.button} ${styles.submitButton}`}>ثبت پاسخ ها</button>
        )}
      </div>
    </div>
  );
};

export default SurveyDetailPageDriver;
