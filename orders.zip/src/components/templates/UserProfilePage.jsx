import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { checkProfile, updateProfile } from '../../services/userService';
import { getUnits } from '../../services/admin';  // درخواست گرفتن واحدها
import Select from 'react-select'; 
import styles from "./UserProfilePage.module.css";
import toast from "react-hot-toast"

const UserProfilePage = () => {
    const [fullName, setFullName] = useState('');
    const [personnelCode, setPersonnelCode] = useState('');
    const [workLocation, setWorkLocation] = useState('');
    const [organization, setOrganization] = useState('');
    const [isLoading, setIsLoading] = useState(true); 
    const [profileIncomplete, setProfileIncomplete] = useState(false);
    const [units, setUnits] = useState([]); // واحدهای دریافتی
    const navigate = useNavigate();

    // دریافت واحدهای سازمانی از بکند
    useEffect(() => {
        const fetchUnits = async () => {
            try {
                const response = await getUnits(); // درخواست به بکند
                const unitOptions = response.data.map(unit => ({
                    value: unit._id,
                    label: unit.organization.name
                }));
                setUnits(unitOptions); // ذخیره واحدها برای نمایش
            } catch (error) {
                console.error("خطا در دریافت واحدها:", error);
            }
        };

        fetchUnits();
    }, []);

    useEffect(() => {
        const verifyProfile = async () => {
            const { response, error } = await checkProfile();
            if (error) {
                console.error("Error checking profile:", error?.response);
                return;
            }
            if (response && response.isProfileCompleted) {
                navigate('/'); 
            } else {
                setProfileIncomplete(true); 
            }
            setIsLoading(false); 
        };

        verifyProfile();
    }, [navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!fullName || !personnelCode || !organization) {
            toast.error("لطفاً تمام فیلدها را پر کنید.");
            return;
        }
        const { response, error } = await updateProfile({ fullName, personnelCode, workLocation, organization });
        if (response) {
            navigate('/');
        } else {
            console.error('Error updating profile:', error);
        }
    };

    if (isLoading) {
        return <div>در حال بارگذاری...</div>; 
    }

    if (!profileIncomplete) {
        return null; 
    }

    return (
        <div className={styles.form}>
            <h1>بروزرسانی اطلاعات کاربر</h1>
            <p>همکار محترم برای ورود اولیه اطلاعات خود را دقیق وارد کنید. در دفعات بعدی نیازی به وارد کردن این اطلاعات نمی باشد</p>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="fullName">نام و نام خانوادگی را وارد کنید:</label>
                    <input
                        id="fullName"
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="نام و نام خانوادگی"
                        required
                    />
                </div>
                <div>
                    <label htmlFor="personnelCode">کد پرسنلی را وارد کنید:</label>
                    <input
                        id="personnelCode"
                        type="text"
                        value={personnelCode}
                        onChange={(e) => setPersonnelCode(e.target.value)}
                        placeholder="کد پرسنلی"
                        required
                    />
                </div>

                <div>
                    <label htmlFor="organization">واحد سازمانی را انتخاب کنید:</label>
                    <Select
                        id="organization"
                        options={units} // استفاده از واحدهای دریافتی
                        getOptionLabel={(option) => option.label}
                        getOptionValue={(option) => option.value}
                        onChange={(newValue) => setOrganization(newValue ? newValue.value : '')}
                        placeholder="واحد سازمانی"
                    />
                </div>
                <button type="submit">ثبت اطلاعات</button>
            </form>
        </div>
    );
};

export default UserProfilePage;
