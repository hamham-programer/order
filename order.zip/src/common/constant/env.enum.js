const NodeEnv = Object.freeze({
    Production : "production",
    Development : "development"
})
module.exports = NodeEnv