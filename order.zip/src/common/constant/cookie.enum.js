const CookieNames = Object.freeze({
    AccessToken : "accessToken",
    RefreshToken : "refreshToken"
})
module.exports = CookieNames