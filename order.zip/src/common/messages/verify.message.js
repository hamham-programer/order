const VerifyMessage = Object.freeze({
    NotAccess: "امکان ویرایش برای شما فراهم نیست لطفا با ادمین ارتباط برقرار کنید",
    
})
module.exports={
    VerifyMessage
}