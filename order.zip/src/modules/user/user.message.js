const UserMessage = Object.freeze({
    NoAccess:"شما اجازه تغییرات مجدد را ندارید",
    UpdateProfile: "بروزرسانی پروفایل با موفقیت انجام شد",
    receive: "لیست کاربران با موفقیت دریافت شد",
    receiveId: " کاربر  با موفقیت دریافت شد",
    NotFoundUser: "کاربری  یافت نشد",
    NotFoundUserId: "کاربری با این اطلاعات یافت نشد",
    

})
module.exports =UserMessage